Inspiration for Article Intro Effects
=========

Some inspiration for article intro effects on headers and fullscreen images.

[Article on Codrops](http://tympanus.net/codrops/?p=19119)

[Demo](http://tympanus.net/Tutorials/ArticleIntroEffects/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2014](http://www.codrops.com)